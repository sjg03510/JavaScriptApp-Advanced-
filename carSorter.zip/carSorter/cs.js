
class Car { 
    constructor(Make, Drive, Transmission, cylinderCount){
        this.Make = Make;
        this.Drive = Drive;
        this.Transmission = Transmission;
        this.cylinderCount = cylinderCount;
    }
}

theResults=document.querySelector("#results");
aCar = [];

aCar[0] = new Car ("BMW", "RWD", "Auto", "6");
aCar[1] = new Car ("Toyota", "FWD", "Auto", "4");
aCar[2] = new Car ("BMW", "AWD", "Auto", "8");
aCar[3] = new Car ("Mazda", "FWD", "Auto", "4");
aCar[4] = new Car ("Nissan", "RWD", "Manual", "6");
aCar[5] = new Car ("Chevy", "AWD", "Manual", "8");
aCar[6] = new Car ("Chevy", "FWD", "Auto", "6");
aCar[7] = new Car ("Ford", "AWD", "Auto", "10");
aCar[8] = new Car ("Ford", "FWD", "Auto", "4");
aCar[9] = new Car ("Mercedes Benz", "RWD", "Auto", "8");
aCar[10] = new Car ("BMW", "RWD", "Manual", "10");
console.log(aCar[2].Make);
console.log('hello');
    
    var make1 = document.querySelector("#make1");
    var make2 = document.querySelector("#make2");
    var make3 = document.querySelector("#make3");
    var make4 = document.querySelector("#make4");
    var make5 = document.querySelector("#make5");
    var make6 = document.querySelector("#make6");
    var make7 = document.querySelector("#make7");
    
    make1.addEventListener('change',checkChange,false);
    make2.addEventListener('change',checkChange,false);
    make3.addEventListener('change',checkChange,false);
    make4.addEventListener('change',checkChange,false);
    make5.addEventListener('change',checkChange,false);
    make6.addEventListener('change',checkChange,false); 
    make7.addEventListener('change',checkChange,false);

    function checkChange(evt){
    console.log("madeit");    
    var str="";
        
        for(var i=0; i<aCar.length; i++){
            console.log(evt.target.value);
            console.log(aCar[2].Make);
            if(aCar[i].Make==evt.target.value){
            
            str +="We have a " + aCar[i].Make + " with a "
                + this.make + " engine.<br/>";
            }
        }
        theResults.innerHTML = str;
    }



